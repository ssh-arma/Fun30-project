# Analysis map and reproducibility notes

The original repository contained four exploratory `.sh` files combining shell commands, shell prompts, Python, R, and analysis commentary. The original text is preserved in categorized `*_legacy.sh` files. **Do not execute these files directly.**

| File | Contents |
| --- | --- |
| `scripts/chipseq/chipseq_insulation_notes_legacy.sh` | BAM merging/sorting/indexing, MACS2 peak calling, peak summaries, insulation analysis notes |
| `scripts/replicates/fun30_brn1_replicates_legacy.sh` | Fun30/Brn1 replicate comparisons, metaplots, GO, WT/deletion comparisons |
| `scripts/visualization/divergent_gene_heatmaps_legacy.sh` | deepTools matrices and heatmaps by gene orientation |
| `scripts/visualization/intergenic_signal_analysis_legacy.sh` | Intergenic signal matrix creation, plotting and BigWig comparisons |
| `scripts/visualization/intergenic_signal_plots.py` | Extracted Python plotting code (requires verification of matrix column parsing) |
| `scripts/go_analysis/go_cluster_enrichment.R` | Extracted GO enrichment and dot plot code |

## Important caveats

- These are archived research commands, **not** a validated runnable workflow.
- The original files include hard-coded cluster paths, sample IDs, interactive commands, and mixed languages.
- One output in the original BigWig comparison notes has a suspicious `.bigwigCompare` filename; verify before use.
- The extracted Python code assumes a particular deepTools matrix layout; validate column offsets and sample/bin labels against actual input files.
- The R GO enrichment script needs four cluster gene lists and appropriate yeast gene identifiers.
- Do not infer biological conclusions solely from file names or exploratory plots.

## Suggested next steps

1. Provide sample metadata and public/restricted data accessions.
2. Split the legacy command logs into independently runnable stages with explicit inputs/outputs.
3. Replace HPC-specific paths with arguments or configuration.
4. Test each stage on a small permitted example dataset.
5. Add representative figures and report validated findings with provenance.
