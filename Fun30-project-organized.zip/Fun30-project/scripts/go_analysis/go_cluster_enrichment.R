# Extracted from original mixed shell/R research notes.
# Requires cluster_1_genes.txt through cluster_4_genes.txt.

library(clusterProfiler)
library(org.Sc.sgd.db)
library(dplyr)
library(ggplot2)

#2. Define gene list files for each cluster ---
cluster_files <- list(
  "Cluster 1" = "cluster_1_genes.txt",
  "Cluster 2" = "cluster_2_genes.txt",
  "Cluster 3" = "cluster_3_genes.txt",
  "Cluster 4" = "cluster_4_genes.txt"
)

#3. Initialize list to hold enrichment results ---
cluster_enrichments <- list()

#4. Perform GO enrichment for each cluster ---
for (name in names(cluster_files)) {
  genes <- scan(cluster_files[[name]], what = "", quiet = TRUE) #what = "" tells scan() to read the file as a character vector 
  
  entrez_ids <- mapIds(
    org.Sc.sgd.db,
    keys = genes,
    column = "ENTREZID",
    keytype = "ORF",
    multiVals = "first"
  )
  entrez_ids <- na.omit(entrez_ids)

  ego <- enrichGO(
    gene = entrez_ids,
    OrgDb = org.Sc.sgd.db,
    ont = "BP",
    pvalueCutoff = 0.05,
    qvalueCutoff = 0.05,
    pAdjustMethod = "BH" #Benjamini-Hochberg multiple testing correction method to control the FDR
  )

  cluster_enrichments[[name]] <- ego
}

# Combine top 5 GO terms from each cluster
combined_top <- do.call(rbind, lapply(names(cluster_enrichments), function(name) {
  ego <- cluster_enrichments[[name]]
  df <- as.data.frame(ego)

  if (nrow(df) == 0) return(NULL)  # skip if no results

  df <- df |>
    dplyr::slice_head(n = 5) |>
    dplyr::mutate(Cluster = name)
  return(df)
}))

# Plot the Dot Plot
p <- ggplot(combined_top, aes(x = Cluster, y = Description)) +
  geom_point(aes(size = Count, color = p.adjust)) +
  scale_color_gradient(low = "red", high = "blue", name = "Adjusted p-value") +
  scale_size(range = c(3, 10), name = "Gene Count") +
  labs(
    title = "Top GO Biological Processes per Cluster",
    x = "Cluster",
    y = "GO Term"
  ) +
  theme_minimal(base_size = 13) +
  theme(
    axis.text.y = element_text(size = 10),
    legend.position = "right"
  )

# Save
ggsave("go_cluster_dotplot_cutoff.png", plot = p, width = 10, height = 6, dpi = 300)
