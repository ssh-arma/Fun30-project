# Data availability

This repository does not include raw sequencing reads, BAM/BigWig files, or restricted laboratory datasets.

To reproduce the analyses, supply appropriately authorized data and matching yeast genome annotations. Original scripts refer to HPC-specific paths that must be configured for your environment.

Document accession numbers, genome build, sample-to-file mappings, and any access restrictions here before claiming a reproducible end-to-end pipeline.
